# Counter-Project
A small JavaScript project that wires two buttons to count up or count down.
